# -----------------------------------------------------------------------------

from unittest.mock import MagicMock, Mock

import pytest

from gitlabcis.cli.auth import enumerateEntities

# -----------------------------------------------------------------------------


@pytest.fixture
def glObject():
    return MagicMock()


def _makeProject(path_with_namespace):
    proj = Mock()
    proj.path_with_namespace = path_with_namespace
    return proj


def _makeGroup(full_path, id=1):
    grp = Mock()
    grp.full_path = full_path
    grp.id = id
    return grp


# -----------------------------------------------------------------------------
# isProject: returns just itself
# -----------------------------------------------------------------------------

def test_enumerate_project_returns_self(glObject):
    proj = _makeProject('mygroup/myproject')
    results = list(enumerateEntities(
        proj, glObject, isGroup=False, isInstance=False, depth=1))

    assert len(results) == 1
    assert results[0]['type'] == 'isProject'
    assert results[0]['slug'] == 'mygroup_myproject'
    assert results[0]['entity'] is proj


# -----------------------------------------------------------------------------
# isGroup: includes group + its projects
# -----------------------------------------------------------------------------

def test_enumerate_group_includes_group_and_projects(glObject):
    grp = _makeGroup('mygroup')
    proj1 = _makeProject('mygroup/proj1')
    proj2 = _makeProject('mygroup/proj2')

    grp.projects.list.return_value = [proj1, proj2]
    grp.subgroups.list.return_value = []

    results = list(enumerateEntities(
        grp, glObject, isGroup=True, isInstance=False, depth=1))

    types = [r['type'] for r in results]
    slugs = [r['slug'] for r in results]

    assert 'isGroup' in types
    assert types.count('isProject') == 2
    assert 'mygroup' in slugs
    assert 'mygroup_proj1' in slugs
    assert 'mygroup_proj2' in slugs


# -----------------------------------------------------------------------------
# isGroup: recurses into subgroups within depth
# -----------------------------------------------------------------------------

def test_enumerate_group_recurses_subgroups(glObject):
    parentGrp = _makeGroup('mygroup', id=1)
    subGrp = _makeGroup('mygroup/sub', id=2)
    subGrpObj = _makeGroup('mygroup/sub', id=2)
    subProj = _makeProject('mygroup/sub/proj')

    parentGrp.projects.list.return_value = []
    parentGrp.subgroups.list.return_value = [subGrp]
    glObject.groups.get.return_value = subGrpObj
    subGrpObj.projects.list.return_value = [subProj]
    subGrpObj.subgroups.list.return_value = []

    results = enumerateEntities(
        parentGrp, glObject, isGroup=True, isInstance=False, depth=0)

    slugs = [r['slug'] for r in results]
    assert 'mygroup' in slugs
    assert 'mygroup_sub' in slugs
    assert 'mygroup_sub_proj' in slugs


# -----------------------------------------------------------------------------
# isGroup: respects depth=1 (no further recursion)
# -----------------------------------------------------------------------------

def test_enumerate_group_respects_depth(glObject):
    parentGrp = _makeGroup('mygroup', id=1)
    subGrp = _makeGroup('mygroup/sub', id=2)
    subGrpObj = _makeGroup('mygroup/sub', id=2)
    deepProj = _makeProject('mygroup/sub/deepproj')

    parentGrp.projects.list.return_value = []
    parentGrp.subgroups.list.return_value = [subGrp]
    glObject.groups.get.return_value = subGrpObj
    subGrpObj.projects.list.return_value = [deepProj]
    subGrpObj.subgroups.list.return_value = []

    results = enumerateEntities(
        parentGrp, glObject, isGroup=True, isInstance=False, depth=1)

    slugs = [r['slug'] for r in results]
    assert 'mygroup' in slugs
    assert 'mygroup_sub' in slugs
    assert 'mygroup_sub_deepproj' in slugs

    results_d0 = enumerateEntities(
        parentGrp, glObject, isGroup=True, isInstance=False,
        depth=1, _current=1)

    slugs_d0 = [r['slug'] for r in results_d0]
    assert 'mygroup_sub' not in slugs_d0


# -----------------------------------------------------------------------------
# Permission errors are skipped with a warning
# -----------------------------------------------------------------------------

def test_enumerate_group_skips_inaccessible_projects(glObject, caplog):
    import logging
    grp = _makeGroup('mygroup')
    grp.projects.list.side_effect = Exception('403 Forbidden')
    grp.subgroups.list.return_value = []

    with caplog.at_level(logging.WARNING, logger='root'):
        results = list(enumerateEntities(
            grp, glObject, isGroup=True, isInstance=False, depth=1))

    types = [r['type'] for r in results]
    assert 'isGroup' in types
    assert 'isProject' not in types


def test_enumerate_group_skips_inaccessible_subgroup(glObject, caplog):
    grp = _makeGroup('mygroup', id=1)
    subGrp = _makeGroup('mygroup/sub', id=2)

    grp.projects.list.return_value = []
    grp.subgroups.list.return_value = [subGrp]
    glObject.groups.get.side_effect = Exception('403 Forbidden')

    results = enumerateEntities(
        grp, glObject, isGroup=True, isInstance=False, depth=0)

    slugs = [r['slug'] for r in results]
    assert 'mygroup' in slugs
    assert 'mygroup_sub' not in slugs


# -----------------------------------------------------------------------------
# isInstance: enumerates top-level groups
# -----------------------------------------------------------------------------

def test_enumerate_instance_top_level_groups(glObject):
    grp1 = _makeGroup('group1', id=1)
    grp1Obj = _makeGroup('group1', id=1)
    grp1Obj.projects.list.return_value = []
    grp1Obj.subgroups.list.return_value = []

    glObject.groups.list.return_value = [grp1]
    glObject.groups.get.return_value = grp1Obj

    results = enumerateEntities(
        None, glObject, isGroup=False, isInstance=True, depth=1)

    slugs = [r['slug'] for r in results]
    assert 'group1' in slugs


def test_enumerate_instance_skips_inaccessible_group(glObject):
    grp1 = _makeGroup('group1', id=1)
    glObject.groups.list.return_value = [grp1]
    glObject.groups.get.side_effect = Exception('403 Forbidden')

    results = list(enumerateEntities(
        None, glObject, isGroup=False, isInstance=True, depth=1))

    assert results == []

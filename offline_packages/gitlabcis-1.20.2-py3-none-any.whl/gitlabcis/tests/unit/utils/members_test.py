# -----------------------------------------------------------------------------

from unittest.mock import Mock

from gitlab.exceptions import GitlabHttpError

from gitlabcis.utils.members import memberAccessPercentage

# -----------------------------------------------------------------------------


def test_memberAccessPercentage(glEntity):
    glEntity.members.list.return_value = [
        Mock(access_level=40),
        Mock(access_level=40),
        Mock(access_level=10)
    ]

    result = memberAccessPercentage(
        glEntity=glEntity,
        min_access_level=40,
        threshold_percentage=50,
        min_count=2
    )

    assert result == (True, 2, (2 / 3) * 100)

    glEntity.members.list.return_value = []
    assert memberAccessPercentage(
        glEntity=glEntity,
        min_access_level=40,
        threshold_percentage=50,
        min_count=2
    ) == {None: 'No members found'}

    glEntity.members.list.side_effect = GitlabHttpError(response_code=401)
    assert memberAccessPercentage(
        glEntity=glEntity,
        min_access_level=40,
        threshold_percentage=50,
        min_count=2
    ) == {None: 'Insufficient permissions'}

    glEntity.members.list.side_effect = GitlabHttpError(response_code=500)
    assert memberAccessPercentage(
        glEntity=glEntity,
        min_access_level=40,
        threshold_percentage=50,
        min_count=2
    ) == {None: 'The server returned: 500'}

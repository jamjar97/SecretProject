# -----------------------------------------------------------------------------


def test_nest_with_output_errors(cmdline):
    exitCode, std = cmdline(
        ['gitlabcis', 'https://gitlab.com/mygroup', '--nest',
         '--output', 'results.json'])

    assert exitCode == 1
    assert 'Use --output-dir with --nest' in std.out


def test_nest_non_terminal_without_output_dir_is_ok(cmdline):
    exitCode, std = cmdline(
        ['gitlabcis', 'https://gitlab.com/mygroup', '--nest',
         '--format', 'json'])

    assert exitCode == 1
    assert 'Use --output-dir with --nest' not in std.out


def test_nest_terminal_no_output_args_is_ok(cmdline):
    exitCode, std = cmdline(
        ['gitlabcis', 'https://gitlab.com/mygroup', '--nest'])

    assert exitCode == 1
    assert 'Use --output-dir with --nest' not in std.out


def test_output_dir_without_format_errors(cmdline):
    exitCode, std = cmdline(
        ['gitlabcis', 'https://gitlab.com/mygroup', '--token', 'fake-token',
         '--output-dir', '/tmp/results'])

    assert exitCode == 1
    assert '--output-dir requires a non-terminal format' in std.out
